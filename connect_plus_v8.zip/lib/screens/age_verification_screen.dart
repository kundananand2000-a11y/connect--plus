import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import 'login_screen.dart';

class AgeVerificationScreen extends StatelessWidget {
  const AgeVerificationScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                width: 110, height: 110,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(color: AppTheme.pink, width: 5),
                ),
                child: const Center(child: Text('18+', style: TextStyle(fontSize: 34, fontWeight: FontWeight.bold))),
              ),
              const SizedBox(height: 28),
              const Text('Age Verification', style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold)),
              const SizedBox(height: 12),
              const Text('This app is for adults only. You must be 18 years or older to continue.', textAlign: TextAlign.center, style: TextStyle(color: Colors.black54, fontSize: 16)),
              const SizedBox(height: 32),
              ElevatedButton(
                onPressed: () => Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const LoginScreen())),
                child: const Text('I am 18+', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w600)),
              ),
              const SizedBox(height: 12),
              OutlinedButton(
                onPressed: () => Navigator.pop(context),
                style: OutlinedButton.styleFrom(minimumSize: const Size(double.infinity, 54), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16))),
                child: const Text('I am under 18'),
              ),
              const SizedBox(height: 20),
              const Text('By continuing, you agree to the Terms & Conditions and Privacy Policy.', textAlign: TextAlign.center, style: TextStyle(fontSize: 11, color: Colors.black45)),
            ],
          ),
        ),
      ),
    );
  }
}
