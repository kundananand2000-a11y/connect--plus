package com.connectplus.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
