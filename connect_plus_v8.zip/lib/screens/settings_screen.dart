import 'package:flutter/material.dart';
import 'report_screen.dart';
class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});
  @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('Settings & Privacy')), body: ListView(children: [
    const SwitchListTile(value: true, onChanged: null, title: Text('Show me in Discover'), subtitle: Text('Control profile visibility')),
    ListTile(leading: const Icon(Icons.notifications_outlined), title: const Text('Notifications'), onTap: () {}),
    ListTile(leading: const Icon(Icons.shield_outlined), title: const Text('Safety & privacy'), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ReportScreen()))),
    ListTile(leading: const Icon(Icons.block_outlined), title: const Text('Blocked users'), onTap: () {}),
    ListTile(leading: const Icon(Icons.delete_outline, color: Colors.red), title: const Text('Delete account', style: TextStyle(color: Colors.red)), onTap: () => showDialog(context: context, builder: (_) => AlertDialog(title: const Text('Delete account?'), content: const Text('This will permanently remove your account and associated data.'), actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')), FilledButton(onPressed: () => Navigator.pop(context), child: const Text('Continue'))])),
  ]));
}
