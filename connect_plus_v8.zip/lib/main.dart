import 'package:flutter/material.dart';
import 'screens/splash_screen.dart';
import 'theme/app_theme.dart';

void main() {
  runApp(const ConnectPlusApp());
}

class ConnectPlusApp extends StatelessWidget {
  const ConnectPlusApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Connect+',
      theme: AppTheme.theme,
      home: const SplashScreen(),
    );
  }
}
