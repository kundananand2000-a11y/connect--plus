import 'package:flutter/material.dart';
import 'chat_screen.dart';
class MatchesScreen extends StatelessWidget {
  const MatchesScreen({super.key});
  final people = const [('Riya', 'Mumbai'), ('Ananya', 'Patna'), ('Priya', 'Delhi')];
  @override Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(16), children: [
    Container(padding: const EdgeInsets.all(18), decoration: BoxDecoration(color: Colors.pink.shade50, borderRadius: BorderRadius.circular(20)), child: const Row(children: [Icon(Icons.favorite, color: Colors.pink, size: 32), SizedBox(width: 12), Expanded(child: Text('It’s a Match! Start a conversation with someone who liked you.', style: TextStyle(fontWeight: FontWeight.w600)))])),
    const SizedBox(height: 18),
    ...people.map((p) => Card(child: ListTile(leading: const CircleAvatar(child: Icon(Icons.person)), title: Text(p.$1), subtitle: Text(p.$2), trailing: FilledButton(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ChatScreen(name: p.$1))), child: const Text('Chat')))),
  ]);
}
