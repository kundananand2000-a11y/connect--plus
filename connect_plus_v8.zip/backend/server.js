import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import jwt from 'jsonwebtoken';
import { Server } from 'socket.io';
import { createServer } from 'http';
import { v4 as uuid } from 'uuid';
import bcrypt from 'bcryptjs';
import pg from 'pg';
const { Pool } = pg;

const app = express();
const httpServer = createServer(app);
const allowedOrigin = process.env.CORS_ORIGIN || '*';
const io = new Server(httpServer, { cors: { origin: allowedOrigin } });
app.use(helmet());
app.use(cors({ origin: allowedOrigin }));
app.use(express.json({ limit: '2mb' }));
app.use(rateLimit({ windowMs: 15 * 60 * 1000, limit: 300, standardHeaders: true, legacyHeaders: false }));
const PORT = process.env.PORT || 3000;
const SECRET = process.env.JWT_SECRET || 'CHANGE_ME_IN_PRODUCTION';
if (SECRET === 'CHANGE_ME_IN_PRODUCTION') console.warn('WARNING: set JWT_SECRET before production.');

const pool = process.env.DATABASE_URL ? new Pool({ connectionString: process.env.DATABASE_URL, ssl: process.env.NODE_ENV === 'production' ? { rejectUnauthorized: false } : false }) : null;
const users = new Map(), credentials = new Map(), likes = new Map(), matches = new Map(), messages = [], blocks = new Set(), reports = [];
const db = async (sql, params=[]) => { if (!pool) return null; return pool.query(sql, params); };
const age18 = (dob) => { const d = new Date(dob), n = new Date(); if (Number.isNaN(d.getTime())) return false; let a=n.getFullYear()-d.getFullYear(); const m=n.getMonth()-d.getMonth(); if(m<0||(m===0&&n.getDate()<d.getDate()))a--; return a>=18; };
const token = u => jwt.sign({sub:u.id}, SECRET, {expiresIn:'7d'});
const pairKey=(a,b)=>[a,b].sort().join(':');
const publicUser=u=>{if(!u)return null; const {passwordHash,password_hash,...safe}=u; return safe;};
function auth(req,res,next){try{const raw=(req.headers.authorization||'').replace('Bearer ','').trim(); req.user=jwt.verify(raw,SECRET); if(!users.has(req.user.sub) && !pool) throw Error('Unknown user'); next();}catch{res.status(401).json({error:'Unauthorized'});}}
function admin(req,res,next){if(!process.env.ADMIN_KEY || req.headers['x-admin-key']!==process.env.ADMIN_KEY)return res.status(403).json({error:'Admin access required'});next();}

app.get('/health', async (q,r)=>{let database='memory'; if(pool){try{await db('SELECT 1');database='postgresql';}catch{database='postgresql-unavailable';}} r.json({ok:true,service:'connect-plus-api',database});});

app.post('/auth/demo', async (req,res)=>{
  const {name,dob,gender,interestedIn,bio=''}=req.body||{}; if(!name||!dob||!age18(dob))return res.status(400).json({error:'18+ verification required'});
  const id=uuid(), u={id,name,dob,gender,interestedIn,bio,verified:true,createdAt:new Date().toISOString()}; users.set(id,u); res.json({user:publicUser(u),token:token(u)});
});
app.post('/auth/register', async (req,res)=>{
  const {name,dob,gender,interestedIn,bio='',email,password,phone}=req.body||{};
  if(!name||!dob||!age18(dob))return res.status(400).json({error:'18+ verification required'});
  if(!email&&!phone)return res.status(400).json({error:'Email or phone is required'});
  const normalizedEmail=email?.toLowerCase();
  if(pool){const existing=await db('SELECT id FROM users WHERE email=$1 OR phone=$2',[normalizedEmail||null,phone||null]);if(existing?.rowCount)return res.status(409).json({error:'Account already exists'});}
  if(email&&credentials.has(`email:${normalizedEmail}`)||phone&&credentials.has(`phone:${phone}`))return res.status(409).json({error:'Account already exists'});
  const passwordHash=password?await bcrypt.hash(password,12):null;
  const id=uuid(), u={id,name,dob,gender,interestedIn,bio,email:normalizedEmail||null,phone:phone||null,passwordHash,verified:false,createdAt:new Date().toISOString()};
  if(pool) await db('INSERT INTO users(id,name,email,phone,password_hash,date_of_birth,gender,interested_in,bio,verified) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)',[id,name,normalizedEmail||null,phone||null,passwordHash,dob,gender||null,interestedIn||null,bio,false]);
  users.set(id,u); if(email)credentials.set(`email:${normalizedEmail}`,id); if(phone)credentials.set(`phone:${phone}`,id);
  res.status(201).json({user:publicUser(u),token:token(u),verification:'provider-required'});
});
app.post('/auth/login',async(req,res)=>{const {email,phone,password}=req.body||{}; const normalized=email?.toLowerCase(); let u=null; if(pool){const q=await db('SELECT id,name,email,phone,password_hash,date_of_birth AS dob,gender,interested_in AS "interestedIn",bio,verified,created_at AS "createdAt" FROM users WHERE email=$1 OR phone=$2',[normalized||null,phone||null]);u=q?.rows[0];} else {const id=credentials.get(email?`email:${normalized}`:`phone:${phone||''}`);u=id&&users.get(id);} if(!u||(u.passwordHash&&!(await bcrypt.compare(password||'',u.passwordHash)))||(u.password_hash&&!(await bcrypt.compare(password||'',u.password_hash))))return res.status(401).json({error:'Invalid credentials'}); res.json({user:publicUser(u),token:token(u)});});

app.get('/me',auth,async(req,res)=>{if(pool){const q=await db('SELECT id,name,email,phone,date_of_birth AS dob,gender,interested_in AS "interestedIn",bio,verified,created_at AS "createdAt" FROM users WHERE id=$1',[req.user.sub]);return res.json(publicUser(q.rows[0]));}res.json(publicUser(users.get(req.user.sub)));});
app.get('/profiles',auth,async(req,res)=>{if(pool){const q=await db(`SELECT id,name,date_of_birth AS dob,gender,interested_in AS "interestedIn",bio,verified,created_at AS "createdAt" FROM users WHERE id<>$1 AND id NOT IN (SELECT to_user FROM likes WHERE from_user=$1) AND id NOT IN (SELECT blocked_id FROM blocks WHERE blocker_id=$1) AND id NOT IN (SELECT blocker_id FROM blocks WHERE blocked_id=$1) LIMIT 50`,[req.user.sub]);return res.json(q.rows.map(publicUser));} const me=req.user.sub,myLikes=likes.get(me)||new Set();res.json([...users.values()].filter(u=>u.id!==me&&!myLikes.has(u.id)&&!blocks.has(pairKey(me,u.id))).map(publicUser));});

app.post('/like/:id',auth,async(req,res)=>{const me=req.user.sub,other=req.params.id;if(me===other)return res.status(400).json({error:'Invalid user'});if(pool){const blocked=await db('SELECT 1 FROM blocks WHERE (blocker_id=$1 AND blocked_id=$2) OR (blocker_id=$2 AND blocked_id=$1)',[me,other]);if(blocked.rowCount)return res.status(400).json({error:'User unavailable'});await db('INSERT INTO likes(from_user,to_user) VALUES($1,$2) ON CONFLICT DO NOTHING',[me,other]);const reciprocal=await db('SELECT 1 FROM likes WHERE from_user=$1 AND to_user=$2',[other,me]);if(reciprocal.rowCount){const id=uuid();await db('INSERT INTO matches(id,user1,user2) VALUES($1,$2,$3) ON CONFLICT(user1,user2) DO NOTHING',[id,...[me,other].sort()]);return res.json({matched:true,match:{id,user1:me,user2:other}});}return res.json({matched:false});}
  if(!users.has(other)||blocks.has(pairKey(me,other)))return res.status(400).json({error:'Invalid user'});if(!likes.has(me))likes.set(me,new Set());likes.get(me).add(other);const reciprocal=likes.get(other)?.has(me);if(reciprocal){const id=uuid(),m={id,user1:me,user2:other,createdAt:new Date().toISOString()};matches.set(pairKey(me,other),m);return res.json({matched:true,match:m});}res.json({matched:false});});
app.get('/matches',auth,async(req,res)=>{if(pool){const q=await db('SELECT id,user1,user2,created_at AS "createdAt" FROM matches WHERE user1=$1 OR user2=$1 ORDER BY created_at DESC',[req.user.sub]);return res.json(q.rows);}res.json([...matches.values()].filter(m=>m.user1===req.user.sub||m.user2===req.user.sub));});
app.get('/messages/:other',auth,async(req,res)=>{if(pool){const q=await db('SELECT id,sender_id AS "senderId",receiver_id AS "receiverId",body AS text,created_at AS "createdAt" FROM messages WHERE deleted_at IS NULL AND ((sender_id=$1 AND receiver_id=$2) OR (sender_id=$2 AND receiver_id=$1)) ORDER BY created_at',[req.user.sub,req.params.other]);return res.json(q.rows);}res.json(messages.filter(m=>!m.deleted&&((m.senderId===req.user.sub&&m.receiverId===req.params.other)||(m.senderId===req.params.other&&m.receiverId===req.user.sub))));});
app.post('/report',auth,async(req,res)=>{const {userId,reason}=req.body||{};if(!userId||!reason)return res.status(400).json({error:'userId and reason required'});const id=uuid();if(pool)await db('INSERT INTO reports(id,reporter_id,reported_user_id,reason) VALUES($1,$2,$3,$4)',[id,req.user.sub,userId,String(reason).slice(0,1000)]);else reports.push({id,reporterId:req.user.sub,userId,reason,status:'open',createdAt:new Date().toISOString()});res.status(201).json({status:'received',id});});
app.post('/block',auth,async(req,res)=>{const userId=req.body?.userId;if(!userId||userId===req.user.sub)return res.status(400).json({error:'Invalid user'});if(pool)await db('INSERT INTO blocks(blocker_id,blocked_id) VALUES($1,$2) ON CONFLICT DO NOTHING',[req.user.sub,userId]);else blocks.add(pairKey(req.user.sub,userId));res.json({blocked:true,userId});});
app.delete('/account',auth,async(req,res)=>{if(pool)await db('DELETE FROM users WHERE id=$1',[req.user.sub]);users.delete(req.user.sub);res.json({deleted:true});});
app.get('/admin/reports',admin,async(req,res)=>{if(pool){const q=await db(`SELECT id,reporter_id AS "reporterId",reported_user_id AS "reportedUserId",reason,status,created_at AS "createdAt" FROM reports ORDER BY created_at DESC LIMIT 200`);return res.json(q.rows);}res.json(reports.slice(-200).reverse());});

io.use((socket,next)=>{try{socket.user=jwt.verify(socket.handshake.auth?.token||'',SECRET);next();}catch{next(new Error('Unauthorized'));}});
io.on('connection',socket=>{socket.join(socket.user.sub);socket.on('chat:send',async({to,text})=>{if(!to||!text||blocks.has(pairKey(socket.user.sub,to)))return;const id=uuid(),body=String(text).trim().slice(0,2000);if(!body)return;let m={id,senderId:socket.user.sub,receiverId:to,text:body,createdAt:new Date().toISOString()};if(pool){const blocked=await db('SELECT 1 FROM blocks WHERE (blocker_id=$1 AND blocked_id=$2) OR (blocker_id=$2 AND blocked_id=$1)',[socket.user.sub,to]);if(blocked.rowCount)return;await db('INSERT INTO messages(id,sender_id,receiver_id,body) VALUES($1,$2,$3,$4)',[id,socket.user.sub,to,body]);}else messages.push(m);io.to(to).emit('chat:message',m);socket.emit('chat:message',m);});socket.on('call:offer',({to,offer})=>io.to(to).emit('call:offer',{from:socket.user.sub,offer}));socket.on('call:answer',({to,answer})=>io.to(to).emit('call:answer',{from:socket.user.sub,answer}));socket.on('call:ice',({to,candidate})=>io.to(to).emit('call:ice',{from:socket.user.sub,candidate}));socket.on('call:end',({to})=>io.to(to).emit('call:end',{from:socket.user.sub}));});

httpServer.listen(PORT,()=>console.log(`Connect+ API listening on :${PORT}`));
