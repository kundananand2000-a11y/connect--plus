import 'dart:async';
import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import 'age_verification_screen.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});
  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    Timer(const Duration(seconds: 2), () {
      if (mounted) {
        Navigator.pushReplacement(context,
          MaterialPageRoute(builder: (_) => const AgeVerificationScreen()));
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Color(0xFF120816), Color(0xFF24102D), Color(0xFF09070B)],
          ),
        ),
        child: Center(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Container(
              width: 92, height: 92,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(color: AppTheme.pink, width: 4),
              ),
              child: const Icon(Icons.favorite, color: AppTheme.pink, size: 48),
            ),
            const SizedBox(height: 22),
            const Text('Connect+', style: TextStyle(color: Colors.white, fontSize: 38, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            const Text('Real People • Real Conversations • Real Connections',
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.white70, fontSize: 13)),
          ]),
        ),
      ),
    );
  }
}
