import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

class VideoCallScreen extends StatelessWidget {
  final String name;
  const VideoCallScreen({super.key, required this.name});
  @override
  Widget build(BuildContext context) {
    return Scaffold(backgroundColor: Colors.black, body: Stack(children: [
      const Center(child: Icon(Icons.person, color: Colors.white24, size: 180)),
      SafeArea(child: Align(alignment: Alignment.topCenter, child: Padding(padding: const EdgeInsets.all(20), child: Column(children: [Text(name, style: const TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold)), const Text('Connecting...', style: TextStyle(color: Colors.white70))])))),
      Positioned(right: 18, top: 70, child: Container(width: 105, height: 145, decoration: BoxDecoration(color: Colors.white12, borderRadius: BorderRadius.circular(16)), child: const Icon(Icons.person, color: Colors.white54, size: 55))),
      Positioned(bottom: 45, left: 0, right: 0, child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
        _callButton(Icons.mic, Colors.white24, Colors.white, () {}), const SizedBox(width: 18),
        _callButton(Icons.call_end, AppTheme.pink, Colors.white, () => Navigator.pop(context)), const SizedBox(width: 18),
        _callButton(Icons.videocam, Colors.white24, Colors.white, () {}),
      ])),
    ]));
  }
  Widget _callButton(IconData icon, Color bg, Color fg, VoidCallback onTap) => CircleAvatar(radius: 30, backgroundColor: bg, child: IconButton(onPressed: onTap, icon: Icon(icon, color: fg)));
}
