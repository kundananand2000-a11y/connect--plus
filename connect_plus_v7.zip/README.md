# Connect+ V7

Connect+ is an 18+ dating-app Flutter prototype with a connected app shell and navigation.

## Connected flow
Splash → 18+ verification → Login/DOB → Profile setup → Home

Home tabs:
- Discover
- Matches
- Chats
- Profile

Additional screens:
- Individual chat
- Video-call UI
- Settings & privacy
- Safety/report
- Account deletion confirmation

## Run on a computer
```bash
flutter pub get
flutter run
```

## Build Android APK
```bash
flutter build apk --release
```
The APK will be produced under `build/app/outputs/flutter-apk/app-release.apk`.

## Important
This is a UI/navigation prototype. Real SMS OTP, production authentication, persistent PostgreSQL data, push notifications, and real WebRTC media still require external services and credentials. Do not put secrets in source control.
