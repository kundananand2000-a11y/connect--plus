import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import 'video_call_screen.dart';

class ChatScreen extends StatefulWidget {
  final String name;
  const ChatScreen({super.key, required this.name});
  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final controller = TextEditingController();
  final messages = <String>['Hi! Nice to match with you 😊', 'Hey! How are you?'];
  @override
  void dispose() { controller.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Row(children: [const CircleAvatar(child: Icon(Icons.person)), const SizedBox(width: 10), Text(widget.name, style: const TextStyle(fontWeight: FontWeight.bold))]), actions: [IconButton(icon: const Icon(Icons.block), onPressed: () => ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('User blocked')))),
        IconButton(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => VideoCallScreen(name: widget.name))), icon: const Icon(Icons.videocam)),
        IconButton(onPressed: () {}, icon: const Icon(Icons.more_vert)),
      ]),
      body: Column(children: [
        Expanded(child: ListView.builder(padding: const EdgeInsets.all(16), itemCount: messages.length, itemBuilder: (_, i) => Align(alignment: i.isOdd ? Alignment.centerRight : Alignment.centerLeft, child: Container(margin: const EdgeInsets.only(bottom: 10), padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12), decoration: BoxDecoration(color: i.isOdd ? AppTheme.pink : Colors.white, borderRadius: BorderRadius.circular(18)), child: Text(messages[i], style: TextStyle(color: i.isOdd ? Colors.white : Colors.black87))))),
        SafeArea(child: Padding(padding: const EdgeInsets.fromLTRB(12, 6, 12, 10), child: Row(children: [
          Expanded(child: TextField(controller: controller, decoration: const InputDecoration(hintText: 'Type a message...'))),
          const SizedBox(width: 8),
          CircleAvatar(backgroundColor: AppTheme.pink, child: IconButton(icon: const Icon(Icons.send, color: Colors.white), onPressed: () { if (controller.text.trim().isNotEmpty) { setState(() { messages.add(controller.text.trim()); controller.clear(); }); } })),
        ]))),
      ]),
    );
  }
}
