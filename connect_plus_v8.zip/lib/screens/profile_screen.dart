import 'package:flutter/material.dart';
import 'settings_screen.dart';
class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});
  @override Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(20), children: [
    const Center(child: CircleAvatar(radius: 58, child: Icon(Icons.person, size: 60))),
    const SizedBox(height: 12), const Center(child: Text('Connect+ User, 22', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold))),
    const SizedBox(height: 6), const Center(child: Text('Real conversations • Good vibes • Travel', textAlign: TextAlign.center)),
    const SizedBox(height: 24),
    Card(child: ListTile(leading: const Icon(Icons.edit_outlined), title: const Text('Edit profile'), trailing: const Icon(Icons.chevron_right), onTap: () {})),
    Card(child: ListTile(leading: const Icon(Icons.settings_outlined), title: const Text('Settings & Privacy'), trailing: const Icon(Icons.chevron_right), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SettingsScreen())))),
  ]);
}
