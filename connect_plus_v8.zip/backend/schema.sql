CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE TABLE IF NOT EXISTS users (
  id uuid PRIMARY KEY,
  name text NOT NULL,
  email text UNIQUE,
  phone text UNIQUE,
  password_hash text,
  date_of_birth date NOT NULL,
  gender text,
  interested_in text,
  bio text DEFAULT '',
  verified boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS likes (
  from_user uuid REFERENCES users(id) ON DELETE CASCADE,
  to_user uuid REFERENCES users(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now(), PRIMARY KEY(from_user,to_user)
);
CREATE TABLE IF NOT EXISTS matches (
  id uuid PRIMARY KEY, user1 uuid REFERENCES users(id) ON DELETE CASCADE,
  user2 uuid REFERENCES users(id) ON DELETE CASCADE, created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(user1,user2)
);
CREATE TABLE IF NOT EXISTS messages (
  id uuid PRIMARY KEY, sender_id uuid REFERENCES users(id) ON DELETE CASCADE,
  receiver_id uuid REFERENCES users(id) ON DELETE CASCADE, body text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(), deleted_at timestamptz
);
CREATE TABLE IF NOT EXISTS reports (
  id uuid PRIMARY KEY, reporter_id uuid REFERENCES users(id) ON DELETE CASCADE,
  reported_user_id uuid REFERENCES users(id) ON DELETE CASCADE, reason text NOT NULL,
  status text NOT NULL DEFAULT 'open', created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS blocks (
  blocker_id uuid REFERENCES users(id) ON DELETE CASCADE,
  blocked_id uuid REFERENCES users(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now(), PRIMARY KEY(blocker_id,blocked_id)
);
CREATE INDEX IF NOT EXISTS messages_pair_idx ON messages(sender_id,receiver_id,created_at);
CREATE INDEX IF NOT EXISTS reports_status_idx ON reports(status,created_at);
