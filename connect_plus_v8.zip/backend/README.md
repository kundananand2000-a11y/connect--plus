# Connect+ API

This backend now supports PostgreSQL when `DATABASE_URL` is configured, with an in-memory development fallback.

## Setup
1. Copy `.env.example` to `.env`.
2. Set a strong `JWT_SECRET` and `ADMIN_KEY`.
3. Create a PostgreSQL database and run `schema.sql`.
4. `npm install`
5. `npm start`

### Important production integrations
- SMS OTP/email verification: connect Firebase Auth or another verified auth provider. Do not treat the `/auth/demo` route as production authentication.
- HTTPS/WSS: terminate TLS at your reverse proxy/load balancer.
- WebRTC: use a TURN server for reliable calls across restrictive networks.
- Moderation: review `/admin/reports`, add image/content moderation, rate limits, and abuse monitoring.
- Privacy: implement retention/deletion policy and obtain required user consent.
