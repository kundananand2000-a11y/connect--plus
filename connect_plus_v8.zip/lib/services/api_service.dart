import 'dart:convert';
import 'package:http/http.dart' as http;

class ApiService {
  ApiService._();
  static final ApiService instance = ApiService._();
  static const base = String.fromEnvironment('API_BASE_URL', defaultValue: 'http://10.0.2.2:3000');
  String? token;

  Map<String, String> get _jsonHeaders => {'content-type': 'application/json'};
  Map<String, String> get _authHeaders => {'content-type': 'application/json', if (token != null) 'Authorization': 'Bearer $token'};

  Future<void> demoLogin({required String name, required String dob}) async {
    final r = await http.post(Uri.parse('$base/auth/demo'), headers: _jsonHeaders, body: jsonEncode({'name': name, 'dob': dob, 'gender': '', 'interestedIn': '', 'bio': ''}));
    final data = jsonDecode(r.body);
    if (r.statusCode != 200) throw Exception(data['error'] ?? 'Login failed');
    token = data['token'];
  }

  Future<List<dynamic>> profiles() async {
    final r = await http.get(Uri.parse('$base/profiles'), headers: _authHeaders);
    final data = jsonDecode(r.body);
    if (r.statusCode != 200) throw Exception(data['error'] ?? 'Could not load profiles');
    return data as List<dynamic>;
  }

  Future<bool> like(String id) async {
    final r = await http.post(Uri.parse('$base/like/$id'), headers: _authHeaders);
    final data = jsonDecode(r.body);
    if (r.statusCode != 200) throw Exception(data['error'] ?? 'Could not like profile');
    return data['matched'] == true;
  }

  Future<void> block(String id) async {
    final r = await http.post(Uri.parse('$base/block'), headers: _authHeaders, body: jsonEncode({'userId': id}));
    if (r.statusCode != 200) throw Exception('Could not block user');
  }

  Future<void> report(String id, String reason) async {
    final r = await http.post(Uri.parse('$base/report'), headers: _authHeaders, body: jsonEncode({'userId': id, 'reason': reason}));
    if (r.statusCode != 201) throw Exception('Could not send report');
  }
}
