import 'package:flutter/material.dart';
import 'chat_screen.dart';
class ChatListScreen extends StatelessWidget {
  const ChatListScreen({super.key});
  final chats = const [('Riya', 'Hey! How are you?', '2m'), ('Ananya', 'Nice to meet you 😊', '18m'), ('Priya', 'Travel plans?', '1h')];
  @override Widget build(BuildContext context) => ListView.builder(itemCount: chats.length, itemBuilder: (_, i) { final c = chats[i]; return ListTile(contentPadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 6), leading: const CircleAvatar(radius: 27, child: Icon(Icons.person)), title: Text(c.$1, style: const TextStyle(fontWeight: FontWeight.bold)), subtitle: Text(c.$2, maxLines: 1, overflow: TextOverflow.ellipsis), trailing: Text(c.$3, style: const TextStyle(fontSize: 12)), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ChatScreen(name: c.$1)))); });
}
