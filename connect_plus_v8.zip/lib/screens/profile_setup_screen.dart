import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import 'home_screen.dart';

class ProfileSetupScreen extends StatefulWidget {
  const ProfileSetupScreen({super.key});
  @override
  State<ProfileSetupScreen> createState() => _ProfileSetupScreenState();
}

class _ProfileSetupScreenState extends State<ProfileSetupScreen> {
  final name = TextEditingController();
  final bio = TextEditingController();
  String gender = 'Male';
  String interestedIn = 'Female';

  @override
  void dispose() { name.dispose(); bio.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Create Your Profile', style: TextStyle(fontWeight: FontWeight.bold))),
      body: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(24, 8, 24, 30),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Center(child: CircleAvatar(radius: 54, child: Icon(Icons.person, size: 55))),
          const SizedBox(height: 24),
          const Text('Your name', style: TextStyle(fontWeight: FontWeight.w600)),
          const SizedBox(height: 8),
          TextField(controller: name, decoration: const InputDecoration(hintText: 'Enter your name')),
          const SizedBox(height: 18),
          const Text('Gender', style: TextStyle(fontWeight: FontWeight.w600)),
          const SizedBox(height: 8),
          SegmentedButton<String>(segments: const [
            ButtonSegment(value: 'Male', label: Text('Male')),
            ButtonSegment(value: 'Female', label: Text('Female')),
            ButtonSegment(value: 'Other', label: Text('Other')),
          ], selected: {gender}, onSelectionChanged: (s) => setState(() => gender = s.first)),
          const SizedBox(height: 18),
          const Text('Interested in', style: TextStyle(fontWeight: FontWeight.w600)),
          const SizedBox(height: 8),
          DropdownButtonFormField<String>(value: interestedIn, decoration: const InputDecoration(), items: const [
            DropdownMenuItem(value: 'Male', child: Text('Men')),
            DropdownMenuItem(value: 'Female', child: Text('Women')),
            DropdownMenuItem(value: 'Both', child: Text('Everyone')),
          ], onChanged: (v) => setState(() => interestedIn = v!)),
          const SizedBox(height: 18),
          const Text('About you', style: TextStyle(fontWeight: FontWeight.w600)),
          const SizedBox(height: 8),
          TextField(controller: bio, maxLines: 4, decoration: const InputDecoration(hintText: 'Write a short bio...')),
          const SizedBox(height: 28),
          ElevatedButton(onPressed: () => Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const HomeScreen())), child: const Text('Continue')),
        ]),
      ),
    );
  }
}
