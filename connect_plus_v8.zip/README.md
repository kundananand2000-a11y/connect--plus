# Connect+ V8 — Android-ready Flutter prototype

Connect+ is an 18+ dating-app Flutter prototype with connected navigation and an Android project structure.

## App flow
Splash → 18+ Verification → Login → Profile Setup → Home

Home tabs: Discover, Matches, Chats, Profile.

Additional screens: individual chat, video-call UI, settings/privacy, safety/report, account deletion confirmation.

## Build on GitHub
A GitHub Actions workflow is included at `.github/workflows/android-apk.yml`.

In GitHub: **Actions → Build Connect+ APK → Run workflow**. After the workflow finishes, open the run and download the artifact named `connect-plus-release-apk`.

## Local build
```bash
flutter pub get
flutter build apk --release
```

## Important
This is still a UI/navigation prototype. Real SMS OTP, production authentication, persistent PostgreSQL data, push notifications, and real WebRTC media require external services and credentials. Never commit secrets.
