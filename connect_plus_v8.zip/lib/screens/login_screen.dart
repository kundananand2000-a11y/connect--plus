import 'package:flutter/material.dart';
import '../services/api_service.dart';
import '../theme/app_theme.dart';
import 'profile_setup_screen.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final phone = TextEditingController();
  final name = TextEditingController(text: 'New Connect+ User');
  DateTime? dob;
  bool loading = false;

  @override void dispose() { phone.dispose(); name.dispose(); super.dispose(); }

  Future<void> pickDob() async {
    final now = DateTime.now();
    final chosen = await showDatePicker(context: context, initialDate: DateTime(now.year - 22), firstDate: DateTime(1940), lastDate: DateTime(now.year - 18, now.month, now.day));
    if (chosen != null) setState(() => dob = chosen);
  }

  Future<void> continueDemo() async {
    if (dob == null) { ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Please select your date of birth.'))); return; }
    setState(() => loading = true);
    try {
      await ApiService.instance.demoLogin(name: name.text.trim().isEmpty ? 'Connect+ User' : name.text.trim(), dob: dob!.toIso8601String().substring(0, 10));
      if (!mounted) return;
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const ProfileSetupScreen()));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString().replaceFirst('Exception: ', ''))));
    } finally { if (mounted) setState(() => loading = false); }
  }

  @override Widget build(BuildContext context) {
    return Scaffold(appBar: AppBar(), body: SafeArea(child: SingleChildScrollView(padding: const EdgeInsets.fromLTRB(24, 20, 24, 30), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Icon(Icons.favorite, color: AppTheme.pink, size: 46), const SizedBox(height: 18),
      const Text('Welcome to Connect+', style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold)),
      const SizedBox(height: 8), const Text('Demo login is connected to the API. Production OTP is added through Firebase/Auth provider.' , style: TextStyle(color: Colors.black54)),
      const SizedBox(height: 26),
      TextField(controller: name, decoration: const InputDecoration(labelText: 'Name')),
      const SizedBox(height: 14),
      TextField(controller: phone, keyboardType: TextInputType.phone, decoration: const InputDecoration(prefixText: '+91  ', labelText: 'Mobile Number')),
      const SizedBox(height: 14),
      OutlinedButton.icon(onPressed: pickDob, icon: const Icon(Icons.cake_outlined), label: Text(dob == null ? 'Select date of birth' : 'DOB: ${dob!.day.toString().padLeft(2,'0')}/${dob!.month.toString().padLeft(2,'0')}/${dob!.year}')),
      const SizedBox(height: 18),
      ElevatedButton(onPressed: loading ? null : continueDemo, child: Text(loading ? 'Connecting...' : 'Continue with 18+ verification')),
      const SizedBox(height: 24), const Center(child: Text('Production: Mobile OTP + Email verification', style: TextStyle(color: Colors.black45))),
    ])));
  }
}
